# Jumble Sort Instructions

Program is written in C++. Program is compiled using g++ (on my OS X system).


Compilation:
------------

$ g++ jumblesort.cc -o jumblesort


Execution Example:
------------------

$ ./jumblesort 1 alpha 2 beta
1 alpha 2 beta