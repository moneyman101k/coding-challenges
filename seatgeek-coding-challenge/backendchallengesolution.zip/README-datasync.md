# Data Center Recovery Instructions

Program is written in C++. Program is compiled using g++ (on my OS X system).


Compilation:
------------

$ g++ datasync.cc -o datasync


Execution Example:
------------------

$ ./datasync < input.txt
1 1 1
1 2 1
done